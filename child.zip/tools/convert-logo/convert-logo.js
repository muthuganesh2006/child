const fs = require('fs');
const path = require('path');
const sharp = require('sharp');

const inPath = path.join(__dirname, '..', '..', 'assets', 'images', 'mg-logo-1.svg');
const outDir = path.join(__dirname, '..', '..', 'assets', 'images');

(async () => {
  try {
    if (!fs.existsSync(inPath)) {
      console.error('Source SVG not found:', inPath);
      process.exit(1);
    }

    const svgBuffer = fs.readFileSync(inPath);

    // Export normal PNG (use SVG intrinsic width if any, else fallback)
    const pngPath = path.join(outDir, 'mg-logo-1.png');
    await sharp(svgBuffer).png().toFile(pngPath);
    console.log('Wrote', pngPath);

    // Export @2x (double width). You can change 800 to desired pixel width.
    const png2xPath = path.join(outDir, 'mg-logo-1@2x.png');
    await sharp(svgBuffer).png({ width: 800 }).toFile(png2xPath);
    console.log('Wrote', png2xPath);

    console.log('Logo export complete.');
  } catch (err) {
    console.error('Error exporting logo:', err);
    process.exit(1);
  }
})();
