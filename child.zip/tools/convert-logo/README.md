Logo conversion helper

Usage

1. Install dependencies

```powershell
cd tools\convert-logo
npm install
```

2. Run conversion

```powershell
npm run convert
```

This reads `assets/images/mg-logo-1.svg` and writes `mg-logo-1.png` and `mg-logo-1@2x.png` into `assets/images`.

Note: `sharp` requires build tools on Windows. If `npm install` fails, install the required build tools or use a package manager that provides prebuilt binaries.
