const fs = require('fs');
const path = require('path');

const dir = 'd:/childfare/Child-Welfare-Foundation-Stackly-main';
const filesList = [];

function getFiles(currentDir) {
    const entries = fs.readdirSync(currentDir, { withFileTypes: true });
    for (const entry of entries) {
        const fullPath = path.join(currentDir, entry.name);
        if (entry.isDirectory()) {
            if (entry.name !== 'node_modules' && entry.name !== '.git') {
                getFiles(fullPath);
            }
        } else if (entry.name.endsWith('.html') || entry.name.endsWith('.css') || entry.name.endsWith('.js')) {
            filesList.push(fullPath);
        }
    }
}

getFiles(dir);

let count = 0;
for (const fullPath of filesList) {
    let content = fs.readFileSync(fullPath, 'utf8');
    let updated = false;

    // Replace any img src or url referencing mg-logo-1.svg, mg-logo-2.svg, mglogo.png, etc. with muthu.png
    const regex = /assets\/images\/(mg-logo-[1-3]\.svg|mg-logo\.svg|mglogo\.png|brand-logo\.webp)/g;
    if (regex.test(content)) {
        content = content.replace(regex, 'assets/images/muthu.png');
        updated = true;
    }

    if (updated) {
        fs.writeFileSync(fullPath, content, 'utf8');
        console.log('Updated logo in:', fullPath);
        count++;
    }
}

console.log(`Successfully updated logo to muthu.png in ${count} files.`);
