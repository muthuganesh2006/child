/*=========================================================
    Child Welfare Dashboard
    dashboard.js
=========================================================*/

document.addEventListener("DOMContentLoaded", () => {

    /*=========================================================
        Dashboard Elements
    =========================================================*/

    const sidebar =
        document.querySelector(".cw-dashboard-sidebar");

    const overlay =
        document.querySelector(".cw-dashboard-overlay");

    const toggle =
        document.querySelector(".cw-dashboard-toggle");

    const closeBtn =
        document.querySelector(".cw-dashboard-close");

    const logoutBtn =
        document.getElementById("dashboardLogout");



    /*=========================================================
        User Data
    =========================================================*/

    const dashboardUserName =
        localStorage.getItem("userName") ||
        sessionStorage.getItem("userName") ||
        "Admin";

    const dashboardUserEmail =
        localStorage.getItem("userEmail") ||
        sessionStorage.getItem("userEmail") ||
        "admin@example.com";



    document.querySelectorAll(".dashboard-user-name")
        .forEach(item => {

            item.textContent =
                dashboardUserName;

        });

    document.querySelectorAll(".dashboard-user-email")
        .forEach(item => {

            item.textContent =
                dashboardUserEmail;

        });



    /*=========================================================
        Mobile Sidebar
    =========================================================*/

    function openSidebar() {

        if (!sidebar || !overlay) return;

        sidebar.classList.add("active");

        overlay.classList.add("active");

        document.body.style.overflow = "hidden";

    }



    function closeSidebar() {

        if (!sidebar || !overlay) return;

        sidebar.classList.remove("active");

        overlay.classList.remove("active");

        document.body.style.overflow = "";

    }



    if (toggle) {

        toggle.addEventListener("click", () => {

            if (window.innerWidth < 992) {

                openSidebar();

            }

        });

    }



    if (closeBtn) {

        closeBtn.addEventListener("click", closeSidebar);

    }



    if (overlay) {

        overlay.addEventListener("click", closeSidebar);

    }



    window.addEventListener("resize", () => {

        if (window.innerWidth >= 992) {

            closeSidebar();

        }

    });



    /*=========================================================
        Logout
    =========================================================*/

    if (logoutBtn) {

        logoutBtn.addEventListener("click", function (e) {

            e.preventDefault();

            localStorage.clear();

            sessionStorage.clear();

            window.location.href = "login.html";

        });

    }



    /*=========================================================
        Counter Animation
    =========================================================*/

    const counters =
        document.querySelectorAll(".counter");

    if (counters.length) {

        const counterObserver =
            new IntersectionObserver(entries => {

                entries.forEach(entry => {

                    if (!entry.isIntersecting) return;

                    const counter =
                        entry.target;

                    const target =
                        parseInt(counter.textContent) || 0;

                    let current = 0;

                    counter.textContent = "0";

                    const timer =
                        setInterval(() => {

                            current +=
                                Math.ceil(target / 60);

                            if (current >= target) {

                                current = target;

                                clearInterval(timer);

                            }

                            counter.textContent = current;

                        }, 20);

                    counterObserver.unobserve(counter);

                });

            });

        counters.forEach(counter => {

            counterObserver.observe(counter);

        });

    }



    /*=========================================================
        Scroll Reveal Animation
    =========================================================*/

    const revealItems = document.querySelectorAll(`
    .cw-dashboard-content,
    .cw-admin-hero,
    .cw-admin-card,
    .cw-admin-analytics-card,
    .cw-admin-client-box,
    .cw-admin-project-box,
    .cw-admin-shortcut-card,
    .cw-client-welcome,
    .cw-client-stat-card,
    .cw-client-card,
    .cw-project-card,
    .cw-project-stat-card,
    .cw-project-toolbar,
    .cw-client-projects-header,
    .cw-report-card,
    .cw-report-stat-card,
    .cw-report-toolbar,
    .cw-client-reports-header,
    .cw-profile-card,
    .cw-profile-stat-card,
    .cw-profile-header
`);

    revealItems.forEach(item => {

        if (item.classList.contains("cw-dashboard-content")) {
            item.classList.add("cw-dashboard-show");
        }

        if (
            item.classList.contains("cw-client-card") ||
            item.classList.contains("cw-client-stat-card") ||
            item.classList.contains("cw-client-welcome")
        ) {
            item.classList.add("cw-client-show");
        }

        if (
            item.classList.contains("cw-project-card") ||
            item.classList.contains("cw-project-stat-card") ||
            item.classList.contains("cw-project-toolbar") ||
            item.classList.contains("cw-client-projects-header")
        ) {
            item.classList.add("cw-project-show");
        }

        if (
            item.classList.contains("cw-report-card") ||
            item.classList.contains("cw-report-stat-card") ||
            item.classList.contains("cw-report-toolbar") ||
            item.classList.contains("cw-client-reports-header")
        ) {
            item.classList.add("cw-report-show");
        }

        if (
            item.classList.contains("cw-profile-card") ||
            item.classList.contains("cw-profile-stat-card") ||
            item.classList.contains("cw-profile-header")
        ) {
            item.classList.add("cw-profile-show");
        }

        if (
            item.classList.contains("cw-admin-card") ||
            item.classList.contains("cw-admin-hero") ||
            item.classList.contains("cw-admin-analytics-card") ||
            item.classList.contains("cw-admin-client-box") ||
            item.classList.contains("cw-admin-project-box") ||
            item.classList.contains("cw-admin-shortcut-card")
        ) {
            item.classList.add("cw-admin-show");
        }

    });
    /*=========================================================
        Client Search
    =========================================================*/

    const clientSearch =
        document.querySelector(".cw-admin-search input");

    const clientCards =
        document.querySelectorAll(".cw-admin-client-box");

    if (clientSearch && clientCards.length) {

        clientSearch.addEventListener("keyup", () => {

            const value =
                clientSearch.value
                    .trim()
                    .toLowerCase();

            clientCards.forEach(card => {

                const column =
                    card.closest('[class*="col"]');

                const text =
                    card.textContent.toLowerCase();

                if (column) {

                    column.style.display =
                        text.includes(value)
                            ? ""
                            : "none";

                }

            });

        });

    }



    /*=========================================================
        Client Status Filter
    =========================================================*/

    const clientFilter =
        document.querySelector(".cw-admin-client-toolbar select");

    if (clientFilter && clientCards.length) {

        clientFilter.addEventListener("change", () => {

            const selected =
                clientFilter.value
                    .trim()
                    .toLowerCase();

            clientCards.forEach(card => {

                const badge =
                    card.querySelector(".badge");

                const column =
                    card.closest('[class*="col"]');

                if (!badge || !column) return;

                const status =
                    badge.textContent
                        .trim()
                        .toLowerCase();

                if (
                    selected === "all clients" ||
                    status === selected
                ) {

                    column.style.display = "";

                }

                else {

                    column.style.display = "none";

                }

            });

        });

    }



/*=========================================================
    Admin Project Search
=========================================================*/

const projectSearch = document.querySelector(".cw-admin-search input");
const projectCards = document.querySelectorAll(".cw-admin-project-box");

if (projectSearch && projectCards.length) {

    projectSearch.addEventListener("keyup", function () {

        const value = this.value.trim().toLowerCase();

        projectCards.forEach(card => {

            const column = card.closest(".col-xl-4, .col-md-6");

            const text = card.textContent.toLowerCase();

            if (column) {

                column.style.display = text.includes(value)
                    ? ""
                    : "none";

            }

        });

    });

}



/*=========================================================
    Admin Project Filter
=========================================================*/

const projectFilter = document.querySelector(".cw-admin-project-toolbar select");

if (projectFilter && projectCards.length) {

    projectFilter.addEventListener("change", function () {

        const selected = this.value.trim().toLowerCase();

        projectCards.forEach(card => {

            const badge = card.querySelector(".badge");

            const column = card.closest(".col-xl-4, .col-md-6");

            if (!badge || !column) return;

            const status = badge.textContent.trim().toLowerCase();

            if (
                selected === "all projects" ||
                status === selected
            ) {

                column.style.display = "";

            } else {

                column.style.display = "none";

            }

        });

    });

}

    /*=========================================================
    Report Search
=========================================================*/

    const reportSearch =
        document.querySelector(".cw-report-search input");

    const reportCards =
        document.querySelectorAll(".cw-report-card");

    if (reportSearch && reportCards.length) {

        reportSearch.addEventListener("keyup", () => {

            const value =
                reportSearch.value
                    .trim()
                    .toLowerCase();

            reportCards.forEach(card => {

                const column =
                    card.closest('[class*="col"]');

                const text =
                    card.textContent.toLowerCase();

                if (column) {

                    column.style.display =
                        text.includes(value)
                            ? ""
                            : "none";

                }

            });

        });

    }



    /*=========================================================
        Report Filter
    =========================================================*/

    const reportFilter =
        document.querySelector(".cw-report-filter select");

    if (reportFilter && reportCards.length) {

        reportFilter.addEventListener("change", () => {

            const selected =
                reportFilter.value
                    .trim()
                    .toLowerCase();

            reportCards.forEach(card => {

                const badge =
                    card.querySelector(".badge");

                const column =
                    card.closest('[class*="col"]');

                if (!badge || !column) return;

                const status =
                    badge.textContent
                        .trim()
                        .toLowerCase();

                column.style.display =
                    selected === "all reports" ||
                        status === selected
                        ? ""
                        : "none";

            });

        });

    }



    /*=========================================================
        Ripple Effect
    =========================================================*/

    document.querySelectorAll(
        ".cw-filter-btn, .cw-report-btn, .cw-admin-primary-btn, .cw-admin-secondary-btn"
    ).forEach(button => {

        button.addEventListener("click", function (e) {

            const ripple =
                document.createElement("span");

            ripple.className =
                "cw-ripple";

            const rect =
                this.getBoundingClientRect();

            ripple.style.left =
                (e.clientX - rect.left) + "px";

            ripple.style.top =
                (e.clientY - rect.top) + "px";

            this.appendChild(ripple);

            setTimeout(() => {

                ripple.remove();

            }, 600);

        });

    });



    /*=========================================================
        Card Hover Effect
    =========================================================*/

    document.querySelectorAll(

        ".cw-admin-card,\
        .cw-admin-client-box,\
        .cw-admin-project-box,\
        .cw-admin-shortcut-card"

    ).forEach(card => {

        card.addEventListener("mousemove", function (e) {

            if (window.innerWidth < 992) return;

            const rect =
                this.getBoundingClientRect();

            const x =
                ((e.clientX - rect.left) / rect.width - 0.5) * 8;

            const y =
                ((e.clientY - rect.top) / rect.height - 0.5) * 8;

            this.style.transform =
                `perspective(1000px)
                rotateY(${x}deg)
                rotateX(${-y}deg)
                translateY(-6px)`;

        });

        card.addEventListener("mouseleave", function () {

            this.style.transform = "";

        });

    });



    /*=========================================================
        Smooth Scroll Top
    =========================================================*/

    window.addEventListener("load", () => {

        window.scrollTo({

            top: 0,

            behavior: "smooth"

        });

    });

    /*=========================================================
    Active Sidebar Menu
=========================================================*/

    const currentPage = window.location.pathname.split("/").pop();

    document.querySelectorAll(".cw-dashboard-menu a").forEach(link => {

        const linkPage = link.getAttribute("href");

        if (linkPage === currentPage) {

            link.classList.add("active");

        }

    });

    /*=========================================================
        Dashboard Loaded
    =========================================================*/

    console.log("Dashboard JS Loaded Successfully.");

});