/*=============================
    Navbar Init
=============================*/

function initNavbar(){

    const navbar = document.querySelector(".cwf-navbar");

    if(!navbar){

        return;

    }

    /*=============================
        Navbar Scroll
    =============================*/

    window.addEventListener("scroll",()=>{

        navbar.classList.toggle("scrolled",window.scrollY > 50);

    });

    /*=============================
        Active Menu
    =============================*/

    const currentPage = window.location.pathname.split("/").pop() || "index.html";

    document.querySelectorAll(".cwf-navbar .nav-link").forEach(link=>{

        const href = link.getAttribute("href");

        if(href === currentPage){

            link.classList.add("active");

        }

    });

}