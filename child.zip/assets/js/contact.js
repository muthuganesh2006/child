/*--- Contact Information Section Start ---*/

/*--- Contact Information Section ---*/

document.addEventListener("DOMContentLoaded", () => {

    const section = document.querySelector(".cw-contact-info-section");

    if (!section) {

        return;

    }

    /*--- Scroll Reveal ---*/

    const revealItems = section.querySelectorAll(

        ".cw-contact-info-header,.cw-contact-info-card"

    );

    const revealObserver = new IntersectionObserver((entries) => {

        entries.forEach(entry => {

            if (entry.isIntersecting) {

                entry.target.classList.add("cw-contact-info-show");

            }

        });

    }, {

        threshold: .15

    });

    revealItems.forEach(item => {

        revealObserver.observe(item);

    });

    /*--- Card Tilt Effect ---*/

    document.querySelectorAll(".cw-contact-info-card").forEach(card => {

        card.addEventListener("mousemove", (e) => {

            if (window.innerWidth < 992) {

                return;

            }

            const rect = card.getBoundingClientRect();

            const x = ((e.clientX - rect.left) / rect.width - .5) * 10;

            const y = ((e.clientY - rect.top) / rect.height - .5) * 10;

            card.style.transform =

                `perspective(1000px)
rotateY(${x}deg)
rotateX(${-y}deg)
translateY(-12px)`;

        });

        card.addEventListener("mouseleave", () => {

            card.style.transform =

                "perspective(1000px) rotateX(0deg) rotateY(0deg) translateY(0)";

        });

    });

    /*--- Icon Parallax ---*/

    document.querySelectorAll(".cw-contact-info-icon").forEach(icon => {

        icon.addEventListener("mousemove", (e) => {

            if (window.innerWidth < 992) {

                return;

            }

            const rect = icon.getBoundingClientRect();

            const x = ((e.clientX - rect.left) / rect.width - .5) * 8;

            const y = ((e.clientY - rect.top) / rect.height - .5) * 8;

            icon.style.transform =

                `perspective(800px)
rotateY(${x}deg)
rotateX(${-y}deg)
scale(1.08)`;

        });

        icon.addEventListener("mouseleave", () => {

            icon.style.transform =

                "perspective(800px) rotateX(0deg) rotateY(0deg) scale(1)";

        });

    });

    /*--- Floating Particles ---*/

    for (let i = 0; i < 20; i++) {

        const particle = document.createElement("span");

        particle.className = "cw-contact-info-particle";

        particle.style.left = Math.random() * 100 + "%";

        particle.style.top = Math.random() * 100 + "%";

        particle.style.animationDelay = Math.random() * 8 + "s";

        particle.style.animationDuration = (8 + Math.random() * 4) + "s";

        section.appendChild(particle);

    }

});

/*--- Contact Information Section End ---*/

/*--- Contact Form Start ---*/

/*--- Get In Touch Section ---*/

document.addEventListener("DOMContentLoaded", () => {

    const form = document.getElementById("cwContactForm");

    if (!form) {

        return;

    }

    const name = document.getElementById("cwName");

    const email = document.getElementById("cwEmail");

    const phone = document.getElementById("cwPhone");

    const subject = document.getElementById("cwSubject");

    const message = document.getElementById("cwMessage");

    const toast = document.querySelector(".cw-contact-form-toast");

    const toastTitle = toast.querySelector("h6");

    const toastText = toast.querySelector("p");

    /*--- Scroll Reveal ---*/

    const revealItems = document.querySelectorAll(

        ".cw-contact-form-header,.cw-contact-form-info,.cw-contact-form-wrapper"

    );

    const revealObserver = new IntersectionObserver((entries) => {

        entries.forEach(entry => {

            if (entry.isIntersecting) {

                entry.target.classList.add("cw-contact-form-show");

            }

        });

    }, {

        threshold: .15

    });

    revealItems.forEach(item => {

        revealObserver.observe(item);

    });

    /*--- Toast ---*/

    let toastTimer;

    function showToast(title, message) {

        toastTitle.innerHTML = title;

        toastText.innerHTML = message;

        toast.classList.add("show");

        clearTimeout(toastTimer);

        toastTimer = setTimeout(() => {

            toast.classList.remove("show");

        }, 3000);

    }

    /*--- Validation Style ---*/

    function setError(input, title, message) {

        input.classList.remove("cw-valid");

        input.classList.add("cw-invalid");

        showToast(title, message);

        input.focus();

    }

    function setSuccess(input) {

        input.classList.remove("cw-invalid");

        input.classList.add("cw-valid");

    }

    /*--- Name Validation ---*/

    function validateName() {

        const value = name.value.trim();

        const regex = /^[A-Za-z\s]+$/;

        if (value === "") {

            setError(name, "Name Required", "Please enter your full name.");

            return false;

        }

        if (!regex.test(value)) {

            setError(name, "Invalid Name", "Only alphabets and spaces are allowed.");

            return false;

        }

        setSuccess(name);

        return true;

    }

    /*--- Email Validation ---*/

    function validateEmail() {

        const value = email.value.trim();

        const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

        if (value === "") {

            setError(email, "Email Required", "Please enter your email address.");

            return false;

        }

        if (!regex.test(value)) {

            setError(email, "Invalid Email", "Please enter a valid email address.");

            return false;

        }

        setSuccess(email);

        return true;

    }

    /*--- Phone Validation ---*/

    function validatePhone() {

        const value = phone.value.trim();

        const regex = /^\d{10}$/;

        if (value === "") {

            setError(phone, "Phone Required", "Please enter your phone number.");

            return false;

        }

        if (!regex.test(value)) {

            setError(phone, "Invalid Phone", "Phone number must contain exactly 10 digits.");

            return false;

        }

        setSuccess(phone);

        return true;

    }

    /*--- Subject Validation ---*/

    function validateSubject() {

        const value = subject.value.trim();

        if (value === "") {

            setError(subject, "Subject Required", "Please enter the subject.");

            return false;

        }

        setSuccess(subject);

        return true;

    }

    /*--- Message Validation ---*/

    function validateMessage() {

        const value = message.value.trim();

        if (value === "") {

            setError(message, "Message Required", "Please enter your message.");

            return false;

        }

        setSuccess(message);

        return true;

    }

    /*--- Input Restrictions ---*/

    name.addEventListener("input", () => {

        name.value = name.value.replace(/[^A-Za-z\s]/g, "");

        validateName();

    });

    phone.addEventListener("input", () => {

        phone.value = phone.value.replace(/\D/g, "").slice(0, 10);

        validatePhone();

    });

    email.addEventListener("input", validateEmail);

    subject.addEventListener("input", validateSubject);

    message.addEventListener("input", validateMessage);

    /*--- Form Submit ---*/

    form.addEventListener("submit", (e) => {

        e.preventDefault();

        const isNameValid = validateName();

        const isEmailValid = validateEmail();

        const isPhoneValid = validatePhone();

        const isSubjectValid = validateSubject();

        const isMessageValid = validateMessage();

        if (

            isNameValid &&

            isEmailValid &&

            isPhoneValid &&

            isSubjectValid &&

            isMessageValid

        ) {

            showToast(

                "Success",

                "Your message has been sent successfully."

            );

            form.reset();

            document.querySelectorAll(".cw-valid").forEach(input => {

                input.classList.remove("cw-valid");

            });

        }

    });

    /*--- Card Tilt ---*/

    document.querySelectorAll(".cw-contact-form-wrapper,.cw-contact-form-info-card").forEach(card => {

        card.addEventListener("mousemove", (e) => {

            if (window.innerWidth < 992) {

                return;

            }

            const rect = card.getBoundingClientRect();

            const x = ((e.clientX - rect.left) / rect.width - .5) * 8;

            const y = ((e.clientY - rect.top) / rect.height - .5) * 8;

            card.style.transform =

                `perspective(1000px)
rotateY(${x}deg)
rotateX(${-y}deg)
translateY(-8px)`;

        });

        card.addEventListener("mouseleave", () => {

            card.style.transform =

                "perspective(1000px) rotateX(0deg) rotateY(0deg) translateY(0)";

        });

    });

    /*--- Floating Particles ---*/

    const section = document.querySelector(".cw-contact-form-section");

    for (let i = 0; i < 18; i++) {

        const particle = document.createElement("span");

        particle.className = "cw-contact-form-particle";

        particle.style.left = Math.random() * 100 + "%";

        particle.style.top = Math.random() * 100 + "%";

        particle.style.animationDelay = Math.random() * 8 + "s";

        particle.style.animationDuration = (8 + Math.random() * 4) + "s";

        section.appendChild(particle);

    }

});

/*--- Contact Form End ---*/

/*--- Frequently Asked Questions Section Start ---*/

/*--- Frequently Asked Questions Section ---*/

document.addEventListener("DOMContentLoaded", () => {

    const section = document.querySelector(".cw-faq-section");

    if (!section) {

        return;

    }

    /*--- Scroll Reveal ---*/

    const revealItems = section.querySelectorAll(

        ".cw-faq-header,.cw-faq-item"

    );

    const revealObserver = new IntersectionObserver((entries) => {

        entries.forEach(entry => {

            if (entry.isIntersecting) {

                entry.target.classList.add("cw-faq-show");

            }

        });

    }, {

        threshold: .15

    });

    revealItems.forEach(item => {

        revealObserver.observe(item);

    });

    /*--- FAQ Accordion ---*/

    const faqItems = document.querySelectorAll(".cw-faq-item");

    faqItems.forEach(item => {

        const button = item.querySelector(".cw-faq-question");

        const answer = item.querySelector(".cw-faq-answer");

        const icon = item.querySelector(".cw-faq-icon i");

        if (item.classList.contains("active")) {

            answer.style.maxHeight = answer.scrollHeight + "px";

            icon.classList.remove("bi-plus-lg");

            icon.classList.add("bi-dash-lg");

        }

        button.addEventListener("click", () => {

            faqItems.forEach(faq => {

                const faqAnswer = faq.querySelector(".cw-faq-answer");

                const faqIcon = faq.querySelector(".cw-faq-icon i");

                if (faq !== item) {

                    faq.classList.remove("active");

                    faqAnswer.style.maxHeight = null;

                    faqIcon.classList.remove("bi-dash-lg");

                    faqIcon.classList.add("bi-plus-lg");

                }

            });

            item.classList.toggle("active");

            if (item.classList.contains("active")) {

                answer.style.maxHeight = answer.scrollHeight + "px";

                icon.classList.remove("bi-plus-lg");

                icon.classList.add("bi-dash-lg");

            } else {

                answer.style.maxHeight = null;

                icon.classList.remove("bi-dash-lg");

                icon.classList.add("bi-plus-lg");

            }

        });

    });

    /*--- Card Tilt Effect ---*/

    document.querySelectorAll(".cw-faq-item").forEach(card => {

        card.addEventListener("mousemove", (e) => {

            if (window.innerWidth < 992) {

                return;

            }

            const rect = card.getBoundingClientRect();

            const x = ((e.clientX - rect.left) / rect.width - .5) * 6;

            const y = ((e.clientY - rect.top) / rect.height - .5) * 6;

            card.style.transform =

                `perspective(1000px)
rotateY(${x}deg)
rotateX(${-y}deg)
translateY(-8px)`;

        });

        card.addEventListener("mouseleave", () => {

            card.style.transform =

                "perspective(1000px) rotateX(0deg) rotateY(0deg) translateY(0)";

        });

    });

    /*--- Floating Particles ---*/

    for (let i = 0; i < 18; i++) {

        const particle = document.createElement("span");

        particle.className = "cw-faq-particle";

        particle.style.left = Math.random() * 100 + "%";

        particle.style.top = Math.random() * 100 + "%";

        particle.style.animationDelay = Math.random() * 8 + "s";

        particle.style.animationDuration = (8 + Math.random() * 4) + "s";

        section.appendChild(particle);

    }

});

/*--- Frequently Asked Questions Section End ---*/

/*--- Google Map Section Start ---*/

/*--- Google Map Section ---*/

document.addEventListener("DOMContentLoaded", () => {

    const section = document.querySelector(".cw-map-section");

    if (!section) {

        return;

    }

    /*--- Scroll Reveal ---*/

    const revealItems = section.querySelectorAll(

        ".cw-map-header,.cw-map-wrapper,.cw-map-card"

    );

    const revealObserver = new IntersectionObserver((entries) => {

        entries.forEach(entry => {

            if (entry.isIntersecting) {

                entry.target.classList.add("cw-map-show");

            }

        });

    }, {

        threshold: .15

    });

    revealItems.forEach(item => {

        revealObserver.observe(item);

    });

    /*--- 3D Card Tilt ---*/

    const mapCard = document.querySelector(".cw-map-card");

    if (mapCard) {

        mapCard.addEventListener("mousemove", (e) => {

            if (window.innerWidth < 992) {

                return;

            }

            const rect = mapCard.getBoundingClientRect();

            const x = ((e.clientX - rect.left) / rect.width - .5) * 10;

            const y = ((e.clientY - rect.top) / rect.height - .5) * 10;

            mapCard.style.transform =

                `perspective(1000px)
rotateY(${x}deg)
rotateX(${-y}deg)
translateY(-10px)`;

        });

        mapCard.addEventListener("mouseleave", () => {

            mapCard.style.transform =

                "perspective(1000px) rotateX(0deg) rotateY(0deg) translateY(0)";

        });

    }

    /*--- Map Zoom Effect ---*/

    const mapWrapper = document.querySelector(".cw-map-wrapper");

    const mapFrame = document.querySelector(".cw-map-frame iframe");

    if (mapWrapper && mapFrame) {

        mapWrapper.addEventListener("mouseenter", () => {

            if (window.innerWidth < 992) {

                return;

            }

            mapFrame.style.transform = "scale(1.04)";

        });

        mapWrapper.addEventListener("mouseleave", () => {

            mapFrame.style.transform = "scale(1)";

        });

    }

    /*--- Floating Particles ---*/

    for (let i = 0; i < 20; i++) {

        const particle = document.createElement("span");

        particle.className = "cw-map-particle";

        particle.style.left = Math.random() * 100 + "%";

        particle.style.top = Math.random() * 100 + "%";

        particle.style.animationDelay = Math.random() * 8 + "s";

        particle.style.animationDuration = (8 + Math.random() * 4) + "s";

        section.appendChild(particle);

    }

});

/*--- Google Map Section End ---*/