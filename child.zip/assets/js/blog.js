/*--- Featured Story Section Start ---*/

document.addEventListener("DOMContentLoaded", () => {

    const section = document.querySelector(".cw-blog-fs-section");

    if (!section) {

        return;

    }

    /*--- Scroll Reveal ---*/

    const revealItems = section.querySelectorAll(".cw-blog-fs-header,.cw-blog-fs-card");

    const revealObserver = new IntersectionObserver((entries) => {

        entries.forEach(entry => {

            if (entry.isIntersecting) {

                entry.target.classList.add("cw-blog-fs-show");

            }

        });

    }, {

        threshold: .15

    });

    revealItems.forEach(item => {

        revealObserver.observe(item);

    });

    /*--- Card Parallax ---*/

    const card = document.querySelector(".cw-blog-fs-card");

    if (card) {

        card.addEventListener("mousemove", (e) => {

            if (window.innerWidth < 992) {

                return;

            }

            const rect = card.getBoundingClientRect();

            const x = ((e.clientX - rect.left) / rect.width - .5) * 10;

            const y = ((e.clientY - rect.top) / rect.height - .5) * 10;

            card.style.transform =

                `perspective(1200px)
rotateY(${x / 3}deg)
rotateX(${-y / 3}deg)
translateY(-10px)`;

        });

        card.addEventListener("mouseleave", () => {

            card.style.transform = "perspective(1200px) rotateX(0deg) rotateY(0deg) translateY(0)";

        });

    }

    /*--- Image Parallax ---*/

    const image = document.querySelector(".cw-blog-fs-image img");

    if (image) {

        image.addEventListener("mousemove", (e) => {

            if (window.innerWidth < 992) {

                return;

            }

            const rect = image.getBoundingClientRect();

            const x = ((e.clientX - rect.left) / rect.width - .5) * 8;

            const y = ((e.clientY - rect.top) / rect.height - .5) * 8;

            image.style.transform =

                `scale(1.08)
translate(${x}px,${y}px)`;

        });

        image.addEventListener("mouseleave", () => {

            image.style.transform = "scale(1) translate(0,0)";

        });

    }

    /*--- Floating Particles ---*/

    for (let i = 0; i < 18; i++) {

        const particle = document.createElement("span");

        particle.className = "cw-blog-fs-particle";

        particle.style.left = Math.random() * 100 + "%";

        particle.style.top = Math.random() * 100 + "%";

        particle.style.animationDelay = Math.random() * 6 + "s";

        particle.style.animationDuration = (6 + Math.random() * 5) + "s";

        section.appendChild(particle);

    }

});

/*--- Featured Story Section End ---*/

/*--- Browse By Category Section Start ---*/

/*--- Browse By Category Section ---*/

document.addEventListener("DOMContentLoaded", () => {

    const section = document.querySelector(".cw-blog-cat-section");

    if (!section) {

        return;

    }

    /*--- Scroll Reveal ---*/

    const revealItems = section.querySelectorAll(

        ".cw-blog-cat-header,.cw-blog-cat-tabs,.cw-blog-cat-grid"

    );

    const revealObserver = new IntersectionObserver((entries) => {

        entries.forEach(entry => {

            if (entry.isIntersecting) {

                entry.target.classList.add("cw-blog-cat-show");

            }

        });

    }, {

        threshold: .15

    });

    revealItems.forEach(item => {

        revealObserver.observe(item);

    });

    /*--- Category Filter ---*/

    const buttons = document.querySelectorAll(".cw-blog-cat-btn");

    const grids = document.querySelectorAll(".cw-blog-cat-grid");

    buttons.forEach(button => {

        button.addEventListener("click", () => {

            const target = button.dataset.category;

            buttons.forEach(btn => {

                btn.classList.remove("cw-blog-cat-btn-active");

            });

            button.classList.add("cw-blog-cat-btn-active");

            grids.forEach(grid => {

                grid.classList.remove("active");

            });

            const activeGrid = document.getElementById(target);

            activeGrid.classList.add("active");

        });

    });

    /*--- Card Tilt ---*/

    document.querySelectorAll(".cw-blog-cat-card").forEach(card => {

        card.addEventListener("mousemove", (e) => {

            if (window.innerWidth < 992) {

                return;

            }

            const rect = card.getBoundingClientRect();

            const x = ((e.clientX - rect.left) / rect.width - .5) * 10;

            const y = ((e.clientY - rect.top) / rect.height - .5) * 10;

            card.style.transform =

                `perspective(1000px)
rotateY(${x}deg)
rotateX(${-y}deg)
translateY(-12px)`;

        });

        card.addEventListener("mouseleave", () => {

            card.style.transform =

                "perspective(1000px) rotateX(0deg) rotateY(0deg) translateY(0)";

        });

    });

    /*--- Image Parallax ---*/

    document.querySelectorAll(".cw-blog-cat-image").forEach(image => {

        image.addEventListener("mousemove", (e) => {

            if (window.innerWidth < 992) {

                return;

            }

            const img = image.querySelector("img");

            const rect = image.getBoundingClientRect();

            const x = ((e.clientX - rect.left) / rect.width - .5) * 10;

            const y = ((e.clientY - rect.top) / rect.height - .5) * 10;

            img.style.transform =

                `scale(1.08)
translate(${x}px,${y}px)`;

        });

        image.addEventListener("mouseleave", () => {

            image.querySelector("img").style.transform =

                "scale(1) translate(0,0)";

        });

    });

    /*--- Floating Particles ---*/

    for (let i = 0; i < 20; i++) {

        const particle = document.createElement("span");

        particle.className = "cw-blog-cat-particle";

        particle.style.left = Math.random() * 100 + "%";

        particle.style.top = Math.random() * 100 + "%";

        particle.style.animationDelay = Math.random() * 6 + "s";

        particle.style.animationDuration = (6 + Math.random() * 4) + "s";

        section.appendChild(particle);

    }

});

/*--- Browse By Category Section End ---*/