/*--- Hero Elements ---*/

const cwAllHeroSection = document.querySelector(".cw-all-hero-section");
const cwAllHeroContent = document.querySelector(".cw-all-hero-content");
const cwAllHeroBlobs = document.querySelectorAll(
    ".cw-all-hero-blob-1, .cw-all-hero-blob-2, .cw-all-hero-blob-3"
);

/*--- Hero Reveal Animation ---*/

if(cwAllHeroContent){

    setTimeout(()=>{

        cwAllHeroContent.classList.add("cw-all-hero-show");

    },200);

}

/*--- Mouse Parallax ---*/

if(cwAllHeroSection){

    cwAllHeroSection.addEventListener("mousemove",(e)=>{

        const rect = cwAllHeroSection.getBoundingClientRect();

        const x = e.clientX - rect.left;

        const y = e.clientY - rect.top;

        const moveX = (x / rect.width - .5) * 25;

        const moveY = (y / rect.height - .5) * 25;

        cwAllHeroBlobs.forEach((blob,index)=>{

            const speed = (index + 1) * .5;

            blob.style.transform =
            `translate(${moveX * speed}px, ${moveY * speed}px)`;

        });

    });

    cwAllHeroSection.addEventListener("mouseleave",()=>{

        cwAllHeroBlobs.forEach((blob)=>{

            blob.style.transform = "translate(0,0)";

        });

    });

}

/*--- Floating Particles ---*/

function cwAllHeroParticles(){

    if(!cwAllHeroSection){

        return;

    }

    for(let i=0;i<20;i++){

        const particle = document.createElement("span");

        particle.className = "cw-all-hero-particle";

        particle.style.left = Math.random()*100+"%";

        particle.style.top = Math.random()*100+"%";

        particle.style.animationDelay = Math.random()*6+"s";

        particle.style.animationDuration =
        5 + Math.random()*5 + "s";

        cwAllHeroSection.appendChild(particle);

    }

}

cwAllHeroParticles();

/*--- Floating Icons Tilt ---*/

const heroIcons = document.querySelectorAll(

    ".cw-all-hero-floating-icon-1, .cw-all-hero-floating-icon-2, .cw-all-hero-floating-icon-3, .cw-all-hero-floating-icon-4"

);

heroIcons.forEach((icon)=>{

    icon.addEventListener("mousemove",(e)=>{

        const rect = icon.getBoundingClientRect();

        const x = e.clientX - rect.left;

        const y = e.clientY - rect.top;

        const rotateY = (x / rect.width - .5) * 18;

        const rotateX = -(y / rect.height - .5) * 18;

        icon.style.transform =

        `perspective(500px)
        rotateX(${rotateX}deg)
        rotateY(${rotateY}deg)
        scale(1.08)`;

    });

    icon.addEventListener("mouseleave",()=>{

        icon.style.transform = "";

    });

});

/*--- Scroll Reveal ---*/

const heroObserver = new IntersectionObserver((entries)=>{

    entries.forEach((entry)=>{

        if(entry.isIntersecting){

            entry.target.classList.add("cw-all-hero-show");

        }

    });

},{

    threshold:.2

});

document.querySelectorAll(

    ".cw-all-hero-badge, .cw-all-hero-title, .cw-all-hero-desc, .cw-all-hero-breadcrumb"

).forEach((item)=>{

    heroObserver.observe(item);

});


/*--- ALL CTA Section ---*/

/*--- Call To Action Section ---*/

document.addEventListener("DOMContentLoaded",()=>{

    const section=document.querySelector(".cw-all-cta-section");

    if(!section){

        return;

    }

    const card=section.querySelector(".cw-all-cta-card");

    /*--- Scroll Reveal ---*/

    const observer=new IntersectionObserver((entries)=>{

        entries.forEach(entry=>{

            if(entry.isIntersecting){

                entry.target.classList.add("cw-all-cta-show");

            }

        });

    },{

        threshold:.2

    });

    observer.observe(card);

    /*--- Mouse Parallax ---*/

    section.addEventListener("mousemove",(e)=>{

        if(window.innerWidth<992){

            return;

        }

        const rect=card.getBoundingClientRect();

        const x=((e.clientX-rect.left)/rect.width-.5)*18;

        const y=((e.clientY-rect.top)/rect.height-.5)*18;

        card.style.transform=

        `perspective(1400px)
        rotateY(${x/5}deg)
        rotateX(${-y/5}deg)
        translateY(-8px)`;

    });

    section.addEventListener("mouseleave",()=>{

        card.style.transform="perspective(1400px) rotateX(0) rotateY(0) translateY(0)";

    });

    /*--- Magnetic Buttons ---*/

    document.querySelectorAll(

        ".cw-all-cta-btn-group a"

    ).forEach(button=>{

        button.addEventListener("mousemove",(e)=>{

            if(window.innerWidth<992){

                return;

            }

            const rect=button.getBoundingClientRect();

            const x=e.clientX-rect.left-rect.width/2;

            const y=e.clientY-rect.top-rect.height/2;

            button.style.transform=

            `translate(${x*.15}px,${y*.15}px)`;

        });

        button.addEventListener("mouseleave",()=>{

            button.style.transform="translate(0,0)";

        });

    });

    /*--- Floating Particles ---*/

    for(let i=0;i<20;i++){

        const particle=document.createElement("span");

        particle.className="cw-all-cta-particle";

        particle.style.left=Math.random()*100+"%";

        particle.style.top=Math.random()*100+"%";

        particle.style.animationDelay=Math.random()*6+"s";

        particle.style.animationDuration=(5+Math.random()*5)+"s";

        section.appendChild(particle);

    }

});