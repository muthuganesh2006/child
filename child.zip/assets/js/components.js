/*--- Load HTML Component ---*/

async function loadComponent(id, file) {

    const element = document.getElementById(id);

    if (!element) return;

    try {

        const response = await fetch(file);

        if (!response.ok) {

            throw new Error(`${file} not found`);

        }

        element.innerHTML = await response.text();

    }

    catch (error) {

        console.error(error);

    }

}

/*--- Initialize Components ---*/

async function initComponents() {

    await Promise.all([

        loadComponent("navbar", "assets/components/navbar.html"),

        loadComponent("footer", "assets/components/footer.html")

    ]);

    if (typeof initNavbar === "function") {

        initNavbar();

    }

    if (typeof initFooter === "function") {

        initFooter();

    }
    

}

document.addEventListener("DOMContentLoaded", initComponents);