/*--- Login Section ---*/

document.addEventListener("DOMContentLoaded", () => {

    const form = document.getElementById("cwLoginForm");

    if (!form) {

        return;

    }

    const email = document.getElementById("loginEmail");

    const password = document.getElementById("loginPassword");

    const togglePassword = document.getElementById("togglePassword");

    const roleCards = document.querySelectorAll(".cw-role-card");

    const roleInputs = document.querySelectorAll("input[name='userRole']");

    const remember = document.getElementById("rememberMe");

    const toast = document.querySelector(".cw-login-toast");

    const toastTitle = toast.querySelector("h6");

    const toastMessage = toast.querySelector("p");

    /*--- Scroll Reveal ---*/

    const revealItems = document.querySelectorAll(

        ".cw-login-card"

    );

    const revealObserver = new IntersectionObserver((entries) => {

        entries.forEach(entry => {

            if (entry.isIntersecting) {

                entry.target.classList.add("cw-login-show");

            }

        });

    }, {

        threshold: .15

    });

    revealItems.forEach(item => {

        revealObserver.observe(item);

    });

    /*--- Toast ---*/

    let toastTimer;

    function showToast(title, message) {

        toastTitle.innerHTML = title;

        toastMessage.innerHTML = message;

        toast.classList.add("show");

        clearTimeout(toastTimer);

        toastTimer = setTimeout(() => {

            toast.classList.remove("show");

        }, 3000);

    }

    /*--- Validation ---*/

    function setError(input, title, message) {

        input.classList.remove("cw-valid");

        input.classList.add("cw-invalid");

        showToast(title, message);

        input.focus();

    }

    function setSuccess(input) {

        input.classList.remove("cw-invalid");

        input.classList.add("cw-valid");

    }

    /*--- Email Validation ---*/

    function validateEmail() {

        const value = email.value.trim();

        const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

        if (value === "") {

            setError(email, "Email Required", "Please enter your email address.");

            return false;

        }

        if (!regex.test(value)) {

            setError(email, "Invalid Email", "Please enter a valid email address.");

            return false;

        }

        setSuccess(email);

        return true;

    }

    /*--- Password Validation ---*/

    function validatePassword() {

        const value = password.value.trim();

        if (value === "") {

            setError(password, "Password Required", "Please enter your password.");

            return false;

        }

        if (value.length < 8) {

            setError(password, "Invalid Password", "Password must contain at least 8 characters.");

            return false;

        }

        setSuccess(password);

        return true;

    }

    /*--- Role Selection ---*/

    roleInputs.forEach(input => {

        input.addEventListener("change", () => {

            roleCards.forEach(card => {

                card.classList.remove("active");

            });

            input.closest(".cw-role-card").classList.add("active");

        });

    });

    /*--- Password Toggle ---*/

    togglePassword.addEventListener("click", () => {

        const icon = togglePassword.querySelector("i");

        if (password.type === "password") {

            password.type = "text";

            icon.classList.remove("bi-eye-fill");

            icon.classList.add("bi-eye-slash-fill");

        } else {

            password.type = "password";

            icon.classList.remove("bi-eye-slash-fill");

            icon.classList.add("bi-eye-fill");

        }

    });

    /*--- Live Validation ---*/

    email.addEventListener("input", validateEmail);

    password.addEventListener("input", validatePassword);

    /*--- Login ---*/

    form.addEventListener("submit", (e) => {

        e.preventDefault();

        const emailValid = validateEmail();

        const passwordValid = validatePassword();

        if (!emailValid || !passwordValid) {

            return;

        }

        const role = document.querySelector("input[name='userRole']:checked").value;

        /*--- Save User Data ---*/

        const storage = remember.checked ? localStorage : sessionStorage;

        storage.setItem("userEmail", email.value.trim());

        storage.setItem("userRole", role);

        storage.setItem("rememberMe", remember.checked);

        /*--- Redirect ---*/

        showToast(

            "Login Successful",

            "Redirecting to your dashboard..."

        );

        setTimeout(() => {

            if (role === "client") {

                window.location.href = "client-dashboard.html";

            } else {

                window.location.href = "admin-dashboard.html";

            }

        }, 1200);

    });

    /*--- Card Tilt ---*/

    const loginCard = document.querySelector(".cw-login-card");

    loginCard.addEventListener("mousemove", (e) => {

        if (window.innerWidth < 992) {

            return;

        }

        const rect = loginCard.getBoundingClientRect();

        const x = ((e.clientX - rect.left) / rect.width - .5) * 8;

        const y = ((e.clientY - rect.top) / rect.height - .5) * 8;

        loginCard.style.transform =

            `perspective(1000px)
rotateY(${x}deg)
rotateX(${-y}deg)
translateY(-8px)`;

    });

    loginCard.addEventListener("mouseleave", () => {

        loginCard.style.transform =

            "perspective(1000px) rotateX(0deg) rotateY(0deg) translateY(0)";

    });

    /*--- Floating Particles ---*/

    const section = document.querySelector(".cw-login-section");

    for (let i = 0; i < 18; i++) {

        const particle = document.createElement("span");

        particle.className = "cw-login-particle";

        particle.style.left = Math.random() * 100 + "%";

        particle.style.top = Math.random() * 100 + "%";

        particle.style.animationDelay = Math.random() * 8 + "s";

        particle.style.animationDuration = (8 + Math.random() * 4) + "s";

        section.appendChild(particle);

    }

});

/*--- Register Page Js ---*/

/*--- Register Section ---*/

document.addEventListener("DOMContentLoaded", () => {

    const form = document.getElementById("cwRegisterForm");

    if (!form) {

        return;

    }

    const name = document.getElementById("registerName");

    const email = document.getElementById("registerEmail");

    const phone = document.getElementById("registerPhone");

    const password = document.getElementById("registerPassword");

    const confirmPassword = document.getElementById("registerConfirmPassword");

    const terms = document.getElementById("acceptTerms");

    const roleCards = document.querySelectorAll(".cw-register-role-card");

    const roleInputs = document.querySelectorAll("input[name='registerRole']");

    const togglePassword = document.getElementById("toggleRegisterPassword");

    const toggleConfirmPassword = document.getElementById("toggleConfirmPassword");

    const toast = document.querySelector(".cw-register-toast");

    const toastTitle = toast.querySelector("h6");

    const toastMessage = toast.querySelector("p");

    /*--- Scroll Reveal ---*/

    const observer = new IntersectionObserver((entries) => {

        entries.forEach(entry => {

            if (entry.isIntersecting) {

                entry.target.classList.add("cw-register-show");

            }

        });

    }, {

        threshold: .15

    });

    observer.observe(document.querySelector(".cw-register-card"));

    /*--- Toast ---*/

    let toastTimer;

    function showToast(title, message) {

        toastTitle.innerHTML = title;

        toastMessage.innerHTML = message;

        toast.classList.add("show");

        clearTimeout(toastTimer);

        toastTimer = setTimeout(() => {

            toast.classList.remove("show");

        }, 3000);

    }

    /*--- Validation Style ---*/

    function setError(input, title, message) {

        input.classList.remove("cw-valid");

        input.classList.add("cw-invalid");

        showToast(title, message);

        input.focus();

    }

    function setSuccess(input) {

        input.classList.remove("cw-invalid");

        input.classList.add("cw-valid");

    }

    /*--- Name Validation ---*/

    function validateName() {

        const value = name.value.trim();

        const regex = /^[A-Za-z\s]+$/;

        if (value === "") {

            setError(name, "Name Required", "Please enter your full name.");

            return false;

        }

        if (!regex.test(value)) {

            setError(name, "Invalid Name", "Only alphabets and spaces are allowed.");

            return false;

        }

        setSuccess(name);

        return true;

    }

    /*--- Email Validation ---*/

    function validateEmail() {

        const value = email.value.trim();

        const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

        if (value === "") {

            setError(email, "Email Required", "Please enter your email address.");

            return false;

        }

        if (!regex.test(value)) {

            setError(email, "Invalid Email", "Please enter a valid email address.");

            return false;

        }

        setSuccess(email);

        return true;

    }

    /*--- Phone Validation ---*/

    function validatePhone() {

        const value = phone.value.trim();

        const regex = /^\d{10}$/;

        if (value === "") {

            setError(phone, "Phone Required", "Please enter your phone number.");

            return false;

        }

        if (!regex.test(value)) {

            setError(phone, "Invalid Phone", "Phone number must contain exactly 10 digits.");

            return false;

        }

        setSuccess(phone);

        return true;

    }

    /*--- Password Validation ---*/

    function validatePassword() {

        const value = password.value;

        const regex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&^#()_\-+=])[A-Za-z\d@$!%*?&^#()_\-+=]{8,}$/;

        if (value === "") {

            setError(password, "Password Required", "Please enter your password.");

            return false;

        }

        if (!regex.test(value)) {

            setError(password, "Weak Password", "Password must contain one uppercase, one lowercase, one number, one special character and minimum 8 characters.");

            return false;

        }

        setSuccess(password);

        return true;

    }

    /*--- Confirm Password ---*/

    function validateConfirmPassword() {

        if (confirmPassword.value === "") {

            setError(confirmPassword, "Confirm Password", "Please confirm your password.");

            return false;

        }

        if (password.value !== confirmPassword.value) {

            setError(confirmPassword, "Password Mismatch", "Passwords do not match.");

            return false;

        }

        setSuccess(confirmPassword);

        return true;

    }

    /*--- Terms Validation ---*/

    function validateTerms() {

        if (!terms.checked) {

            showToast("Terms Required", "Please accept the Terms & Conditions.");

            return false;

        }

        return true;

    }

    /*--- Live Restrictions ---*/

    name.addEventListener("input", () => {

        name.value = name.value.replace(/[^A-Za-z\s]/g, "");

        validateName();

    });

    phone.addEventListener("input", () => {

        phone.value = phone.value.replace(/\D/g, "").slice(0, 10);

        validatePhone();

    });

    email.addEventListener("input", validateEmail);

    password.addEventListener("input", validatePassword);

    confirmPassword.addEventListener("input", validateConfirmPassword);

    /*--- Password Toggle ---*/

    togglePassword.addEventListener("click", () => {

        const icon = togglePassword.querySelector("i");

        if (password.type === "password") {

            password.type = "text";

            icon.classList.replace("bi-eye-fill", "bi-eye-slash-fill");

        } else {

            password.type = "password";

            icon.classList.replace("bi-eye-slash-fill", "bi-eye-fill");

        }

    });

    toggleConfirmPassword.addEventListener("click", () => {

        const icon = toggleConfirmPassword.querySelector("i");

        if (confirmPassword.type === "password") {

            confirmPassword.type = "text";

            icon.classList.replace("bi-eye-fill", "bi-eye-slash-fill");

        } else {

            confirmPassword.type = "password";

            icon.classList.replace("bi-eye-slash-fill", "bi-eye-fill");

        }

    });

    /*--- Role Selection ---*/

    roleInputs.forEach(input => {

        input.addEventListener("change", () => {

            roleCards.forEach(card => {

                card.classList.remove("active");

            });

            input.closest(".cw-register-role-card").classList.add("active");

        });

    });

    /*--- Submit ---*/

    form.addEventListener("submit", (e) => {

        e.preventDefault();

        const validName = validateName();

        const validEmail = validateEmail();

        const validPhone = validatePhone();

        const validPassword = validatePassword();

        const validConfirm = validateConfirmPassword();

        const validTerms = validateTerms();

        if (!(validName && validEmail && validPhone && validPassword && validConfirm && validTerms)) {

            return;

        }

        const role = document.querySelector("input[name='registerRole']:checked").value;

        /*--- Save User Data ---*/

        localStorage.setItem("userName", name.value.trim());

        localStorage.setItem("userEmail", email.value.trim());

        localStorage.setItem("userPhone", phone.value.trim());

        localStorage.setItem("userRole", role);

        /*--- Success ---*/

        showToast(

            "Registration Successful",

            "Redirecting to your Login Page..."

        );

        setTimeout(() => {

            if (role === "client") {

                window.location.href = "login.html";

            } else {

                window.location.href = "login.html";

            }

        }, 1200);

    });

    /*--- Card Tilt ---*/

    const card = document.querySelector(".cw-register-card");

    card.addEventListener("mousemove", (e) => {

        if (window.innerWidth < 992) {

            return;

        }

        const rect = card.getBoundingClientRect();

        const x = ((e.clientX - rect.left) / rect.width - .5) * 8;

        const y = ((e.clientY - rect.top) / rect.height - .5) * 8;

        card.style.transform =

            `perspective(1000px)
rotateY(${x}deg)
rotateX(${-y}deg)
translateY(-8px)`;

    });

    card.addEventListener("mouseleave", () => {

        card.style.transform = "perspective(1000px) rotateX(0deg) rotateY(0deg) translateY(0)";

    });

    /*--- Floating Particles ---*/

    const section = document.querySelector(".cw-register-section");

    for (let i = 0; i < 18; i++) {

        const particle = document.createElement("span");

        particle.className = "cw-register-particle";

        particle.style.left = Math.random() * 100 + "%";

        particle.style.top = Math.random() * 100 + "%";

        particle.style.animationDelay = Math.random() * 8 + "s";

        particle.style.animationDuration = (8 + Math.random() * 4) + "s";

        section.appendChild(particle);

    }

});