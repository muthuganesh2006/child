/*--- About Section ---*/

document.addEventListener("DOMContentLoaded", () => {

    /*--- Counter Animation ---*/

    const counters = document.querySelectorAll(".ab-counter");

    const counterObserver = new IntersectionObserver((entries) => {

        entries.forEach(entry => {

            if (entry.isIntersecting) {

                counters.forEach(counter => {

                    let target = parseInt(counter.dataset.count);

                    let current = 0;

                    let increment = target / 120;

                    function update() {

                        current += increment;

                        if (current < target) {

                            counter.innerText = Math.floor(current).toLocaleString();

                            requestAnimationFrame(update);

                        } else {

                            counter.innerText = target.toLocaleString() + "+";

                        }

                    }

                    update();

                });

                counterObserver.disconnect();

            }

        });

    }, { threshold: .4 });

    const statSection = document.querySelector(".ab-stat");

    if (statSection) {

        counterObserver.observe(statSection);

    }

    /*--- Scroll Reveal ---*/

    const revealItems = document.querySelectorAll(".ab-card,.ab-center,.ab-stat,.ab-heading");

    const revealObserver = new IntersectionObserver((entries) => {

        entries.forEach(entry => {

            if (entry.isIntersecting) {

                entry.target.classList.add("ab-show");

            }

        });

    }, { threshold: .15 });

    revealItems.forEach(item => {

        item.classList.add("ab-hidden");

        revealObserver.observe(item);

    });

    /*--- Card Tilt Effect ---*/

    document.querySelectorAll(".ab-card").forEach(card => {

        card.addEventListener("mousemove", (e) => {

            const rect = card.getBoundingClientRect();

            const x = e.clientX - rect.left;

            const y = e.clientY - rect.top;

            const rotateY = ((x - rect.width / 2) / 18);

            const rotateX = ((rect.height / 2 - y) / 18);

            card.style.transform =
                `perspective(900px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) translateY(-8px)`;

        });

        card.addEventListener("mouseleave", () => {

            card.style.transform = "perspective(900px) rotateX(0deg) rotateY(0deg) translateY(0px)";

        });

    });

    /*--- Mouse Glow ---*/

    document.querySelectorAll(".ab-card").forEach(card => {

        card.addEventListener("mousemove", (e) => {

            const rect = card.getBoundingClientRect();

            const x = e.clientX - rect.left;

            const y = e.clientY - rect.top;

            card.style.background =

                `radial-gradient(circle at ${x}px ${y}px,
rgba(59,130,246,.18),
rgba(255,255,255,.82) 65%)`;

        });

        card.addEventListener("mouseleave", () => {

            card.style.background = "rgba(255,255,255,.75)";

        });

    });

    /*--- Floating Center Ring ---*/

    const ring = document.querySelector(".ab-center-ring");

    let degree = 0;

    function rotateRing() {

        degree += 0.08;

        if (ring) {

            ring.style.transform = `rotate(${degree}deg)`;

        }

        requestAnimationFrame(rotateRing);

    }

    rotateRing();

    /*--- Center Circle Parallax ---*/

    const center = document.querySelector(".ab-center-circle");

    document.addEventListener("mousemove", (e) => {

        if (window.innerWidth < 992) return;

        const x = (window.innerWidth / 2 - e.clientX) / 45;

        const y = (window.innerHeight / 2 - e.clientY) / 45;

        center.style.transform = `translate(${x}px,${y}px)`;

    });

    /*--- Button Hover Ripple ---*/

    const button = document.querySelector(".primary-btn");

    if (button) {

        button.addEventListener("mouseenter", () => {

            button.style.transition = ".35s";

            button.style.transform = "translateY(-5px)";

        });

        button.addEventListener("mouseleave", () => {

            button.style.transform = "translateY(0px)";

        });

    }

});



/*--- What We Do Section ---*/

document.addEventListener("DOMContentLoaded", () => {

    /*--- Scroll Reveal ---*/

    const revealItems = document.querySelectorAll(".wd-heading,.wd-card,.wd-cta");

    const revealObserver = new IntersectionObserver((entries) => {

        entries.forEach(entry => {

            if (entry.isIntersecting) {

                entry.target.classList.add("wd-show");

                revealObserver.unobserve(entry.target);

            }

        });

    }, {
        threshold: .15
    });

    revealItems.forEach(item => {

        item.classList.add("wd-hidden");

        revealObserver.observe(item);

    });

    /*--- Card Tilt ---*/

    if (window.innerWidth > 991) {

        document.querySelectorAll(".wd-card").forEach(card => {

            card.addEventListener("mousemove", (e) => {

                const rect = card.getBoundingClientRect();

                const x = e.clientX - rect.left;

                const y = e.clientY - rect.top;

                const rotateY = ((x - (rect.width / 2)) / 25);

                const rotateX = (((rect.height / 2) - y) / 25);

                card.style.transform = `perspective(1200px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) translateY(-10px)`;

            });

            card.addEventListener("mouseleave", () => {

                card.style.transform = "";

            });

        });

    }

    /*--- Parallax Artwork ---*/

    if (window.innerWidth > 991) {

        document.querySelectorAll(".wd-card").forEach(card => {

            const artwork = card.querySelector(".wd-art img");

            if (!artwork) return;

            card.addEventListener("mousemove", (e) => {

                const rect = card.getBoundingClientRect();

                const x = (e.clientX - rect.left) / rect.width;

                const y = (e.clientY - rect.top) / rect.height;

                const moveX = (x - .5) * 18;

                const moveY = (y - .5) * 18;

                artwork.style.transform = `translate(${moveX}px,${moveY}px) scale(1.05)`;

            });

            card.addEventListener("mouseleave", () => {

                artwork.style.transform = "";

            });

        });

    }

    /*--- CTA Light Effect ---*/

    const cta = document.querySelector(".wd-cta");

    if (cta) {

        cta.addEventListener("mousemove", (e) => {

            const rect = cta.getBoundingClientRect();

            const x = e.clientX - rect.left;

            const y = e.clientY - rect.top;

            cta.style.background =

                `radial-gradient(circle at ${x}px ${y}px,
rgba(255,255,255,.18),
transparent 45%),
linear-gradient(135deg,#2563eb,#3b82f6)`;

        });

        cta.addEventListener("mouseleave", () => {

            cta.style.background = "linear-gradient(135deg,#2563eb,#3b82f6)";

        });

    }

    /*--- Button Hover ---*/

    document.querySelectorAll(".wd-link").forEach(link => {

        link.addEventListener("mouseenter", () => {

            const icon = link.querySelector("i");

            if (icon) {

                icon.style.transform = "translate(5px,-5px)";

            }

        });

        link.addEventListener("mouseleave", () => {

            const icon = link.querySelector("i");

            if (icon) {

                icon.style.transform = "";

            }

        });

    });

    /*--- Mobile Touch ---*/

    if (window.innerWidth < 992) {

        document.querySelectorAll(".wd-card").forEach(card => {

            card.addEventListener("touchstart", () => {

                card.style.transform = "translateY(-6px)";

            });

            card.addEventListener("touchend", () => {

                setTimeout(() => {

                    card.style.transform = "";

                }, 180);

            });

        });

    }

});

/*--- Journey of a Child ---*/

document.addEventListener("DOMContentLoaded", () => {

    const jcSteps = document.querySelectorAll(".jc-step");
    const jcPath = document.querySelector(".jc-path");

    /*--- Reveal Animation ---*/

    const revealObserver = new IntersectionObserver((entries) => {

        entries.forEach(entry => {

            if (entry.isIntersecting) {

                entry.target.classList.add("active");

            }

        });

    }, {
        threshold: 0.25
    });

    jcSteps.forEach(step => {

        revealObserver.observe(step);

    });

    /*--- Timeline Progress ---*/

function updateTimeline() {

    if (!jcPath) return;

    const section = document.querySelector(".jc-journey");

    const rect = section.getBoundingClientRect();

    const progress = Math.max(
        0,
        Math.min(
            (window.innerHeight - rect.top) /
            (rect.height + window.innerHeight),
            1
        )
    );

    jcPath.style.setProperty(
        "--jc-progress",
        `${progress * 120}%`
    );

}

    window.addEventListener("scroll", updateTimeline);

    updateTimeline();

    /*--- Active Step Highlight ---*/

    const activeObserver = new IntersectionObserver((entries) => {

        entries.forEach(entry => {

            if (entry.isIntersecting) {

                jcSteps.forEach(step => {

                    step.classList.remove("current");

                });

                entry.target.classList.add("current");

            }

        });

    }, {
        threshold: 0.6
    });

    jcSteps.forEach(step => {

        activeObserver.observe(step);

    });

    /*--- Card Hover Motion ---*/

    jcSteps.forEach(step => {

        const card = step.querySelector(".jc-card");

        step.addEventListener("mousemove", (e) => {

            const rect = card.getBoundingClientRect();

            const x = e.clientX - rect.left;

            const y = e.clientY - rect.top;

            const rotateX = ((y / rect.height) - 0.5) * -6;

            const rotateY = ((x / rect.width) - 0.5) * 6;

            card.style.transform =
                `perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) translateY(-8px)`;

        });

        step.addEventListener("mouseleave", () => {

            card.style.transform = "";

        });

    });

});

/*--- Testimonials Slider ---*/

const tsSlider = new Swiper(".ts-slider", {

    loop: true,

    speed: 900,

    grabCursor: true,

    centeredSlides: false,

    autoHeight:true,

    slidesPerView: 1,

    spaceBetween: 30,

    autoplay: {

        delay: 5000,

        disableOnInteraction: false,

        pauseOnMouseEnter: true

    },

    pagination: {

        el: ".swiper-pagination",

        clickable: true

    },

    navigation: {

        nextEl: ".ts-next",

        prevEl: ".ts-prev"

    },

    keyboard: {

        enabled: true,

        onlyInViewport: true

    },

    breakpoints: {

        768: {

            slidesPerView: 1.15

        },

        992: {

            slidesPerView: 1.25

        },

        1200: {

            slidesPerView: 1.35

        }

    },

    on: {

        init: function () {

            tsUpdateActive();

        },

        slideChangeTransitionEnd: function () {

            tsUpdateActive();

        }

    }

});

/*--- Active Slide ---*/

function tsUpdateActive() {

    document.querySelectorAll(".ts-card").forEach(card => {

        card.classList.remove("ts-active");

    });

    const activeCard = document.querySelector(".swiper-slide-active .ts-card");

    if (activeCard) {

        activeCard.classList.add("ts-active");

    }

}

tsUpdateActive();

/*--- Reveal Animation ---*/

const tsObserver = new IntersectionObserver((entries) => {

    entries.forEach(entry => {

        if (entry.isIntersecting) {

            entry.target.classList.add("ts-show");

            tsObserver.unobserve(entry.target);

        }

    });

}, {

    threshold: 0.25

});

document.querySelectorAll(".ts-card").forEach(card => {

    tsObserver.observe(card);

});

/*--- Mouse Tilt Effect ---*/

document.querySelectorAll(".ts-card").forEach(card => {

    card.addEventListener("mousemove", (e) => {

        const rect = card.getBoundingClientRect();

        const x = e.clientX - rect.left;

        const y = e.clientY - rect.top;

        const rotateX = ((y / rect.height) - 0.5) * -8;

        const rotateY = ((x / rect.width) - 0.5) * 8;

        card.style.transform = `perspective(1200px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) translateY(-10px)`;

    });

    card.addEventListener("mouseleave", () => {

        card.style.transform = "";

    });

});

/*--- Pause Slider When Hidden ---*/

document.addEventListener("visibilitychange", () => {

    if (document.hidden) {

        tsSlider.autoplay.stop();

    } else {

        tsSlider.autoplay.start();

    }

});

/*--- Pause On Hover ---*/

const tsSection = document.querySelector(".ts-slider");

if (tsSection) {

    tsSection.addEventListener("mouseenter", () => {

        tsSlider.autoplay.stop();

    });

    tsSection.addEventListener("mouseleave", () => {

        tsSlider.autoplay.start();

    });

}

/*--- Call To Action Section ---*/

document.addEventListener("DOMContentLoaded", () => {

    /*--- Reveal Animation ---*/

    const ctaObserver = new IntersectionObserver((entries) => {

        entries.forEach((entry) => {

            if (entry.isIntersecting) {

                entry.target.classList.add("cta-show");

            }

        });

    }, {

        threshold: 0.25

    });

    document.querySelectorAll(".cta-card").forEach((card) => {

        ctaObserver.observe(card);

    });

    /*--- Mouse Parallax ---*/

    const ctaCard = document.querySelector(".cta-card");

    if (ctaCard && window.innerWidth > 991) {

        ctaCard.addEventListener("mousemove", (e) => {

            const rect = ctaCard.getBoundingClientRect();

            const x = e.clientX - rect.left;

            const y = e.clientY - rect.top;

            const rotateY = ((x / rect.width) - 0.5) * 8;

            const rotateX = ((y / rect.height) - 0.5) * -8;

            ctaCard.style.transform =
                `perspective(1200px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) translateY(-8px)`;

        });

        ctaCard.addEventListener("mouseleave", () => {

            ctaCard.style.transform = "";

        });

    }

    /*--- Button Ripple Effect ---*/

    document.querySelectorAll(".primary-btn, .outline-btn").forEach((button) => {

        button.addEventListener("click", function (e) {

            const ripple = document.createElement("span");

            ripple.className = "cta-ripple";

            const rect = this.getBoundingClientRect();

            ripple.style.left = `${e.clientX - rect.left}px`;

            ripple.style.top = `${e.clientY - rect.top}px`;

            this.appendChild(ripple);

            setTimeout(() => {

                ripple.remove();

            }, 600);

        });

    });

});