/*--- 404 Error Section ---*/

document.addEventListener("DOMContentLoaded", () => {

    /*--- Smart Go Back Button ---*/

    const goBackBtn = document.getElementById("goBackBtn");

    if (goBackBtn) {

        goBackBtn.addEventListener("click", (e) => {

            e.preventDefault();

            if (window.history.length > 1) {

                history.back();

            } else {

                window.location.href = "index.html";

            }

        });

    }

    /*--- Reveal Animation ---*/

    const errorObserver = new IntersectionObserver((entries) => {

        entries.forEach((entry) => {

            if (entry.isIntersecting) {

                entry.target.classList.add("er-show");

            }

        });

    }, {

        threshold:0.2

    });

    document.querySelectorAll(".er-card").forEach((card) => {

        errorObserver.observe(card);

    });

    /*--- Mouse Tilt Effect ---*/

    const errorCard = document.querySelector(".er-card");

    if (errorCard && window.innerWidth > 991) {

        errorCard.addEventListener("mousemove", (e) => {

            const rect = errorCard.getBoundingClientRect();

            const x = e.clientX - rect.left;

            const y = e.clientY - rect.top;

            const rotateY = ((x / rect.width) - .5) * 8;

            const rotateX = ((y / rect.height) - .5) * -8;

            errorCard.style.transform =
                `perspective(1400px)
                rotateX(${rotateX}deg)
                rotateY(${rotateY}deg)
                translateY(-8px)`;

        });

        errorCard.addEventListener("mouseleave", () => {

            errorCard.style.transform = "";

        });

    }

    /*--- Button Ripple Effect ---*/

    document.querySelectorAll(".primary-btn, .outline-btn").forEach((button) => {

        button.addEventListener("click", function (e) {

            const ripple = document.createElement("span");

            ripple.className = "er-ripple";

            const rect = this.getBoundingClientRect();

            ripple.style.left = `${e.clientX - rect.left}px`;

            ripple.style.top = `${e.clientY - rect.top}px`;

            this.appendChild(ripple);

            setTimeout(() => {

                ripple.remove();

            }, 600);

        });

    });

});