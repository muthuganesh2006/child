/*--- Who We Are Section ---*/

document.addEventListener("DOMContentLoaded",()=>{

    const section=document.querySelector(".cw-abtp-wwa-section");

    if(!section){

        return;

    }

    /*--- Scroll Reveal ---*/

    const revealItems=section.querySelectorAll(

        ".cw-abtp-wwa-image-wrapper, .cw-abtp-wwa-content, .cw-abtp-wwa-item"

    );

    const revealObserver=new IntersectionObserver((entries)=>{

        entries.forEach(entry=>{

            if(entry.isIntersecting){

                entry.target.classList.add("cw-abtp-wwa-show");

            }

        });

    },{

        threshold:.15

    });

    revealItems.forEach(item=>{

        revealObserver.observe(item);

    });

    /*--- Mouse Parallax ---*/

    const imageWrapper=section.querySelector(".cw-abtp-wwa-image-wrapper");

    if(imageWrapper){

        imageWrapper.addEventListener("mousemove",(e)=>{

            const rect=imageWrapper.getBoundingClientRect();

            const x=((e.clientX-rect.left)/rect.width-.5)*18;

            const y=((e.clientY-rect.top)/rect.height-.5)*18;

            imageWrapper.style.transform=`rotateY(${x}deg) rotateX(${-y}deg)`;

        });

        imageWrapper.addEventListener("mouseleave",()=>{

            imageWrapper.style.transform="perspective(1000px) rotateX(0deg) rotateY(0deg)";

        });

    }

    /*--- Floating Particles ---*/

    for(let i=0;i<12;i++){

        const particle=document.createElement("span");

        particle.className="cw-abtp-wwa-particle";

        particle.style.left=Math.random()*100+"%";

        particle.style.top=Math.random()*100+"%";

        particle.style.animationDelay=Math.random()*6+"s";

        particle.style.animationDuration=(5+Math.random()*5)+"s";

        section.appendChild(particle);

    }

});

/*--- Mission & Vision Section ---*/

document.addEventListener("DOMContentLoaded",()=>{

    const section=document.querySelector(".cw-abtp-mv-section");

    if(!section){

        return;

    }

    /*--- Scroll Reveal ---*/

    const revealItems=section.querySelectorAll(

        ".cw-abtp-mv-header, .cw-abtp-mv-card, .cw-abtp-mv-center, .cw-abtp-mv-principle"

    );

    const observer=new IntersectionObserver((entries)=>{

        entries.forEach(entry=>{

            if(entry.isIntersecting){

                entry.target.classList.add("cw-abtp-mv-show");

            }

        });

    },{

        threshold:.15

    });

    revealItems.forEach(item=>{

        observer.observe(item);

    });

    /*--- Mouse Parallax ---*/

    const centerCircle=section.querySelector(".cw-abtp-mv-center-circle");

    if(centerCircle){

        section.addEventListener("mousemove",(e)=>{

            const rect=section.getBoundingClientRect();

            const x=((e.clientX-rect.left)/rect.width-.5)*16;

            const y=((e.clientY-rect.top)/rect.height-.5)*16;

            centerCircle.style.transform=`translate(${x}px,${y}px)`;

        });

        section.addEventListener("mouseleave",()=>{

            centerCircle.style.transform="translate(0,0)";

        });

    }

    /*--- Floating Particles ---*/

    for(let i=0;i<15;i++){

        const particle=document.createElement("span");

        particle.className="cw-abtp-mv-particle";

        particle.style.left=Math.random()*100+"%";

        particle.style.top=Math.random()*100+"%";

        particle.style.animationDelay=Math.random()*6+"s";

        particle.style.animationDuration=(5+Math.random()*5)+"s";

        section.appendChild(particle);

    }

});

/*--- Our Core Values Section ---*/

document.addEventListener("DOMContentLoaded",()=>{

    const section=document.querySelector(".cw-abtp-cv-section");

    if(!section){

        return;

    }

    /*--- Scroll Reveal ---*/

    const revealItems=section.querySelectorAll(

        ".cw-abtp-cv-header, .cw-abtp-cv-item"

    );

    const observer=new IntersectionObserver((entries)=>{

        entries.forEach(entry=>{

            if(entry.isIntersecting){

                entry.target.classList.add("cw-abtp-cv-show");

            }

        });

    },{

        threshold:.15

    });

    revealItems.forEach(item=>{

        observer.observe(item);

    });

    /*--- Mouse Parallax Icons ---*/

    const icons=section.querySelectorAll(".cw-abtp-cv-icon");

    icons.forEach(icon=>{

        icon.addEventListener("mousemove",(e)=>{

            const rect=icon.getBoundingClientRect();

            const x=((e.clientX-rect.left)/rect.width-.5)*18;

            const y=((e.clientY-rect.top)/rect.height-.5)*18;

            icon.style.transform=`rotateY(${x}deg) rotateX(${-y}deg)`;

        });

        icon.addEventListener("mouseleave",()=>{

            icon.style.transform="rotateX(0deg) rotateY(0deg)";

        });

    });

    /*--- Floating Particles ---*/

    for(let i=0;i<18;i++){

        const particle=document.createElement("span");

        particle.className="cw-abtp-cv-particle";

        particle.style.left=Math.random()*100+"%";

        particle.style.top=Math.random()*100+"%";

        particle.style.animationDelay=Math.random()*8+"s";

        particle.style.animationDuration=(5+Math.random()*6)+"s";

        section.appendChild(particle);

    }

});

/*--- Meet Our Team Section ---*/

document.addEventListener("DOMContentLoaded",()=>{

    const section=document.querySelector(".cw-abtp-team-section");

    if(!section){

        return;

    }

    /*--- Scroll Reveal ---*/

    const revealItems=section.querySelectorAll(

        ".cw-abtp-team-header, .cw-abtp-team-feature, .cw-abtp-team-card"

    );

    const observer=new IntersectionObserver((entries)=>{

        entries.forEach(entry=>{

            if(entry.isIntersecting){

                entry.target.classList.add("cw-abtp-team-show");

            }

        });

    },{

        threshold:.15

    });

    revealItems.forEach(item=>{

        observer.observe(item);

    });

    /*--- Featured Image Parallax ---*/

    const featuredImage=section.querySelector(".cw-abtp-team-feature-image");

    if(featuredImage){

        featuredImage.addEventListener("mousemove",(e)=>{

            const rect=featuredImage.getBoundingClientRect();

            const x=((e.clientX-rect.left)/rect.width-.5)*12;

            const y=((e.clientY-rect.top)/rect.height-.5)*12;

            featuredImage.style.transform=`rotateY(${x}deg) rotateX(${-y}deg)`;

        });

        featuredImage.addEventListener("mouseleave",()=>{

            featuredImage.style.transform="rotateX(0deg) rotateY(0deg)";

        });

    }

    /*--- Team Card Parallax ---*/

    document.querySelectorAll(".cw-abtp-team-card").forEach(card=>{

        card.addEventListener("mousemove",(e)=>{

            const rect=card.getBoundingClientRect();

            const x=((e.clientX-rect.left)/rect.width-.5)*10;

            const y=((e.clientY-rect.top)/rect.height-.5)*10;

            card.style.transform=

            `perspective(1000px) rotateY(${x}deg) rotateX(${-y}deg) translateY(-10px)`;

        });

        card.addEventListener("mouseleave",()=>{

            card.style.transform="perspective(1000px) rotateX(0deg) rotateY(0deg)";

        });

    });

    /*--- Floating Particles ---*/

    for(let i=0;i<20;i++){

        const particle=document.createElement("span");

        particle.className="cw-abtp-team-particle";

        particle.style.left=Math.random()*100+"%";

        particle.style.top=Math.random()*100+"%";

        particle.style.animationDelay=Math.random()*8+"s";

        particle.style.animationDuration=(6+Math.random()*5)+"s";

        section.appendChild(particle);

    }

});