/*--------------------------------------------------
    Loader
--------------------------------------------------*/

const loader = document.querySelector(".ar-loader");
const counter = document.getElementById("loader-count");

let loaderInterval = null;

/*--------------------------------------------------
    Show Loader
--------------------------------------------------*/

function showLoader() {

    if (!loader) return;

    loader.style.display = "flex";
    loader.style.opacity = "1";
    loader.style.visibility = "visible";

    if (counter) {

        counter.textContent = "0";

    }

    let count = 0;

    clearInterval(loaderInterval);

    const loaderBar = document.querySelector(".ar-loader-bar");

    loaderInterval = setInterval(() => {

        count++;

        if (counter) {

            counter.textContent = count;

        }

        if (loaderBar) {

            loaderBar.style.width = count + "%";

        }

        if (count >= 100) {

            clearInterval(loaderInterval);

        }

    }, 10);

}

/*--------------------------------------------------
    Hide Loader
--------------------------------------------------*/

function hideLoader() {

    if (!loader) return;

    setTimeout(() => {

        loader.style.opacity = "0";
        loader.style.visibility = "hidden";

        setTimeout(() => {

            loader.style.display = "none";

        }, 800);

    }, 1000);

}

/*--------------------------------------------------
    Initial Page Load
--------------------------------------------------*/

document.addEventListener("DOMContentLoaded", () => {

    showLoader();

});

window.addEventListener("load", () => {

    hideLoader();

});

/*--------------------------------------------------
    Browser Back / Forward
--------------------------------------------------*/

window.addEventListener("pageshow", (event) => {

    if (event.persisted) {

        showLoader();

        hideLoader();

    }

});

/*--------------------------------------------------
    Loader Progress
--------------------------------------------------*/

const loaderBar = document.querySelector(".ar-loader-bar");

/*--------------------------------------------------
    Loading Messages
--------------------------------------------------*/

const loaderMessages = [

    "Preparing Hope...",
    "Loading Smiles...",
    "Building Dreams...",
    "Almost Ready..."

];

const loaderText = document.querySelector(".ar-loader-card p");

/*--------------------------------------------------
    Floating Particles
--------------------------------------------------*/

function createLoaderParticles(){

    if(!loader){

        return;

    }

    for(let i = 0; i < 20; i++){

        const particle = document.createElement("span");

        particle.className = "ar-loader-particle";

        particle.style.left = Math.random() * 100 + "%";

        particle.style.top = Math.random() * 100 + "%";

        particle.style.animationDelay = Math.random() * 5 + "s";

        particle.style.animationDuration = 4 + Math.random() * 5 + "s";

        loader.appendChild(particle);

    }

}


/*--------------------------------------------------
    Mouse Glow
--------------------------------------------------*/

document.addEventListener("mousemove",(e)=>{

    if(!loader || loader.style.display === "none"){

        return;

    }

    loader.style.setProperty("--x",e.clientX + "px");

    loader.style.setProperty("--y",e.clientY + "px");

});

/*--------------------------------------------------
    Init
--------------------------------------------------*/

document.addEventListener("DOMContentLoaded",()=>{

    createLoaderParticles();

});

/*--------------------------------------------------
    Replace Counter Update
--------------------------------------------------*/

/*


*/