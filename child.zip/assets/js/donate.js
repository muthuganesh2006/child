document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('offline-donate-form');
  if (!form) return;

  form.addEventListener('submit', async (e) => {
    e.preventDefault();

    const name = form.querySelector('[name="name"]').value.trim();
    const email = form.querySelector('[name="email"]').value.trim();
    const amount = form.querySelector('[name="amount"]').value.trim();
    const message = form.querySelector('[name="message"]').value.trim();

    const statusEl = document.getElementById('donate-status');
    statusEl.textContent = 'Sending...';

    try {
      const resp = await fetch('/api/donations', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, email, amount, message })
      });

      const data = await resp.json();

      if (!resp.ok) throw new Error(data.error || 'Request failed');

      statusEl.innerHTML = `<strong>Thank you, ${data.donation.name}!</strong><br/>` +
        `Please complete a bank transfer using these details:<br/>` +
        `<pre style="white-space:pre-wrap;margin:0">Account: ${data.instructions.account_name}\nAccount No: ${data.instructions.account_number}\nBank: ${data.instructions.bank}\nIFSC: ${data.instructions.ifsc}\nUPI: ${data.instructions.upi}\nReference: ${data.instructions.note}</pre>`;

      form.reset();
    } catch (err) {
      statusEl.textContent = 'Error sending donation. Try again later.';
      console.error(err);
    }

  });

});
