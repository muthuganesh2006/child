/*--- Programs Overview Section ---*/

document.addEventListener("DOMContentLoaded", () => {

    const section = document.querySelector(".cw-prg-ov-section");

    if (!section) {

        return;

    }

    /*--- Scroll Reveal ---*/

    const revealItems = section.querySelectorAll(

        ".cw-prg-ov-header, .cw-prg-ov-tree, .cw-prg-ov-program, .cw-prg-ov-quote"

    );

    const observer = new IntersectionObserver((entries) => {

        entries.forEach(entry => {

            if (entry.isIntersecting) {

                entry.target.classList.add("cw-prg-ov-show");

            }

        });

    }, {

        threshold: .15

    });

    revealItems.forEach(item => {

        observer.observe(item);

    });

    /*--- Tree Parallax ---*/

    const tree = document.querySelector(".cw-prg-ov-tree");

    if (tree) {

        tree.addEventListener("mousemove", (e) => {

            if (window.innerWidth < 992) {

                return;

            }

            const rect = tree.getBoundingClientRect();

            const x = ((e.clientX - rect.left) / rect.width - .5) * 16;

            const y = ((e.clientY - rect.top) / rect.height - .5) * 16;

            tree.style.transform =

                `translate(-50%,-50%)
            perspective(1000px)
            rotateY(${x / 4}deg)
            rotateX(${-y / 4}deg)
            scale(1.03)`;

        });

        tree.addEventListener("mouseleave", () => {

            tree.style.transform = "translate(-50%,-50%)";

        });

    }

    /*--- Program Card Tilt ---*/

    document.querySelectorAll(".cw-prg-ov-node").forEach(card => {

        card.addEventListener("mousemove", (e) => {

            if (window.innerWidth < 992) {

                return;

            }

            const rect = card.getBoundingClientRect();

            const x = ((e.clientX - rect.left) / rect.width - .5) * 10;

            const y = ((e.clientY - rect.top) / rect.height - .5) * 10;

            card.style.transform =

                `perspective(900px)
            rotateY(${x}deg)
            rotateX(${-y}deg)
            translateY(-8px)`;

        });

        card.addEventListener("mouseleave", () => {

            card.style.transform =

                "perspective(900px) rotateX(0deg) rotateY(0deg)";

        });

    });

    /*--- Floating Leaves ---*/

    for (let i = 0; i < 18; i++) {

        const leaf = document.createElement("span");

        leaf.className = "cw-prg-ov-leaf";

        leaf.style.left = Math.random() * 100 + "%";

        leaf.style.animationDelay = Math.random() * 8 + "s";

        leaf.style.animationDuration = (8 + Math.random() * 5) + "s";

        leaf.style.opacity = .2 + Math.random() * .4;

        section.appendChild(leaf);

    }

});

/*--- Featured Programs Section Start ---*/

/*--- Featured Programs Section ---*/

document.addEventListener("DOMContentLoaded", () => {

    const section = document.querySelector(".cw-prg-fp-section");

    if (!section) {

        return;

    }

    /*--- Scroll Reveal ---*/

    const items = section.querySelectorAll(

        ".cw-prg-fp-header, .cw-prg-fp-item"

    );

    const observer = new IntersectionObserver((entries) => {

        entries.forEach(entry => {

            if (entry.isIntersecting) {

                entry.target.classList.add("cw-prg-fp-show");

            }

        });

    }, {

        threshold: .15

    });

    items.forEach(item => {

        observer.observe(item);

    });

    /*--- Image Parallax ---*/

    document.querySelectorAll(".cw-prg-fp-image-wrap").forEach(image => {

        image.addEventListener("mousemove", (e) => {

            if (window.innerWidth < 992) {

                return;

            }

            const rect = image.getBoundingClientRect();

            const x = ((e.clientX - rect.left) / rect.width - .5) * 16;

            const y = ((e.clientY - rect.top) / rect.height - .5) * 16;

            image.style.transform =

                `perspective(1000px)
            rotateY(${x / 5}deg)
            rotateX(${-y / 5}deg)
            translateY(-8px)`;

        });

        image.addEventListener("mouseleave", () => {

            image.style.transform = "perspective(1000px) rotateX(0) rotateY(0)";

        });

    });

    /*--- Glass Card Tilt ---*/

    document.querySelectorAll(".cw-prg-fp-content").forEach(card => {

        card.addEventListener("mousemove", (e) => {

            if (window.innerWidth < 992) {

                return;

            }

            const rect = card.getBoundingClientRect();

            const x = ((e.clientX - rect.left) / rect.width - .5) * 10;

            const y = ((e.clientY - rect.top) / rect.height - .5) * 10;

            card.style.transform =

                `perspective(1000px)
            rotateY(${x}deg)
            rotateX(${-y}deg)
            translateY(-10px)`;

        });

        card.addEventListener("mouseleave", () => {

            card.style.transform =

                "perspective(1000px) rotateX(0) rotateY(0)";

        });

    });

    /*--- Floating Particles ---*/

    for (let i = 0; i < 25; i++) {

        const particle = document.createElement("span");

        particle.className = "cw-prg-fp-particle";

        particle.style.left = Math.random() * 100 + "%";

        particle.style.top = Math.random() * 100 + "%";

        particle.style.animationDelay = Math.random() * 6 + "s";

        particle.style.animationDuration = (6 + Math.random() * 5) + "s";

        section.appendChild(particle);

    }

});

/*--- Featured Programs Section End ---*/

/*--- Program Impact Section Start ---*/

/*--- Program Impact Section ---*/

document.addEventListener("DOMContentLoaded", () => {

    const section = document.querySelector(".cw-prg-impact-section");

    if (!section) {

        return;

    }

    /*--- Scroll Reveal ---*/

    const revealItems = section.querySelectorAll(

        ".cw-prg-impact-header,.cw-prg-impact-dashboard,.cw-prg-impact-card,.cw-prg-impact-center"

    );

    const revealObserver = new IntersectionObserver((entries) => {

        entries.forEach(entry => {

            if (entry.isIntersecting) {

                entry.target.classList.add("cw-prg-impact-show");

            }

        });

    }, {

        threshold: .15

    });

    revealItems.forEach(item => {

        revealObserver.observe(item);

    });

    /*--- Counter Animation ---*/

    const counters = document.querySelectorAll(".cw-prg-impact-number");

    const counterObserver = new IntersectionObserver((entries) => {

        entries.forEach(entry => {

            if (!entry.isIntersecting) {

                return;

            }

            const counter = entry.target;

            const target = parseInt(counter.dataset.count);

            let current = 0;

            const duration = 1800;

            const step = Math.max(1, Math.ceil(target / (duration / 16)));

            const update = () => {

                current += step;

                if (current < target) {

                    if (target === 25000) {

                        counter.innerHTML = current.toLocaleString() + "+";

                    }

                    else if (target === 98) {

                        counter.innerHTML = current + "%";

                    }

                    else {

                        counter.innerHTML = current + "+";

                    }

                    requestAnimationFrame(update);

                }

                else {

                    if (target === 25000) {

                        counter.innerHTML = "25,000+";

                    }

                    else if (target === 98) {

                        counter.innerHTML = "98%";

                    }

                    else {

                        counter.innerHTML = target + "+";

                    }

                }

            };

            update();

            counterObserver.unobserve(counter);

        });

    }, {

        threshold: .4

    });

    counters.forEach(counter => {

        counterObserver.observe(counter);

    });

    /*--- Card Tilt Effect ---*/

    document.querySelectorAll(".cw-prg-impact-card").forEach(card => {

        card.addEventListener("mousemove", (e) => {

            if (window.innerWidth < 992) {

                return;

            }

            const rect = card.getBoundingClientRect();

            const x = ((e.clientX - rect.left) / rect.width - .5) * 12;

            const y = ((e.clientY - rect.top) / rect.height - .5) * 12;

            card.style.transform =

                `perspective(1000px)
rotateY(${x}deg)
rotateX(${-y}deg)
translateY(-10px)`;

        });

        card.addEventListener("mouseleave", () => {

            card.style.transform = "perspective(1000px) rotateX(0deg) rotateY(0deg) translateY(0)";

        });

    });

    /*--- Globe Parallax ---*/

    const globe = document.querySelector(".cw-prg-impact-globe");

    if (globe) {

        globe.addEventListener("mousemove", (e) => {

            if (window.innerWidth < 992) {

                return;

            }

            const rect = globe.getBoundingClientRect();

            const x = ((e.clientX - rect.left) / rect.width - .5) * 10;

            const y = ((e.clientY - rect.top) / rect.height - .5) * 10;

            globe.style.transform =

                `perspective(1000px)
rotateY(${x}deg)
rotateX(${-y}deg)
scale(1.08)`;

        });

        globe.addEventListener("mouseleave", () => {

            globe.style.transform = "perspective(1000px) rotateX(0deg) rotateY(0deg) scale(1)";

        });

    }

    /*--- Floating Particles ---*/

    for (let i = 0; i < 18; i++) {

        const particle = document.createElement("span");

        particle.className = "cw-prg-impact-particle";

        particle.style.left = Math.random() * 100 + "%";

        particle.style.top = Math.random() * 100 + "%";

        particle.style.animationDelay = Math.random() * 6 + "s";

        particle.style.animationDuration = (6 + Math.random() * 4) + "s";

        section.appendChild(particle);

    }

});

/*--- Program Impact Section End ---*/