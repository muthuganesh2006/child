const fs = require('fs');
const path = require('path');

const dir = 'd:/childfare/Child-Welfare-Foundation-Stackly-main';
const filesList = [];

function getFiles(currentDir) {
    const entries = fs.readdirSync(currentDir, { withFileTypes: true });
    for (const entry of entries) {
        const fullPath = path.join(currentDir, entry.name);
        if (entry.isDirectory()) {
            if (entry.name !== 'node_modules' && entry.name !== '.git') {
                getFiles(fullPath);
            }
        } else if (entry.name.endsWith('.html') || entry.name.endsWith('.css') || entry.name.endsWith('.js')) {
            filesList.push(fullPath);
        }
    }
}

getFiles(dir);

for (const fullPath of filesList) {
    let content = fs.readFileSync(fullPath, 'utf8');
    let updated = false;
    const matches = content.match(/assets\/images\/[^\s\"']+/g);
    if (matches) {
        for (const m of matches) {
            if (m.includes('logo') && !m.includes('mglogo.png')) {
                content = content.split(m).join('assets/images/muthu.png');
                updated = true;
            }
        }
    }
    if (updated) {
        fs.writeFileSync(fullPath, content, 'utf8');
        console.log('Updated logo reference in:', fullPath);
    }
}
console.log('Done updating logos!');
