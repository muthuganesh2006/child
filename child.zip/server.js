const express = require('express');
const path = require('path');
const fs = require('fs');
const cors = require('cors');
const morgan = require('morgan');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());
app.use(morgan('dev'));

// Serve static site files from project root
app.use(express.static(path.join(__dirname)));

const DATA_FILE = path.join(__dirname, 'donations.json');

function readDonations() {
  try {
    const raw = fs.readFileSync(DATA_FILE, 'utf8');
    return JSON.parse(raw || '[]');
  } catch (err) {
    return [];
  }
}

function writeDonations(list) {
  fs.writeFileSync(DATA_FILE, JSON.stringify(list, null, 2), 'utf8');
}

// Simple API to record donation intents (offline/free method: bank transfer)
app.post('/api/donations', (req, res) => {
  const { name, email, amount, message } = req.body || {};

  if (!name || !email || !amount) {
    return res.status(400).json({ error: 'name, email and amount are required' });
  }

  const donations = readDonations();

  const donation = {
    id: Date.now(),
    name,
    email,
    amount: Number(amount),
    message: message || '',
    timestamp: new Date().toISOString()
  };

  donations.push(donation);
  writeDonations(donations);

  // Return offline bank transfer instructions (placeholder values)
  const instructions = {
    method: 'bank_transfer',
    account_name: 'Child Welfare Foundation',
    account_number: '1234567890',
    bank: 'Example Bank',
    ifsc: 'EXAMP000000',
    upi: 'childwelfare@upi',
    note: 'Use donation ID ' + donation.id + ' as payment reference.'
  };

  return res.json({ donation, instructions });
});

app.get('/api/donations', (req, res) => {
  const donations = readDonations();
  res.json(donations);
});

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
